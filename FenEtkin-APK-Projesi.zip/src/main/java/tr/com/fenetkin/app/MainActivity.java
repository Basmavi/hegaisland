package tr.com.fenetkin.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebRequestError;

public class MainActivity extends Activity {
    private static final String HOME = "https://fenetkin.com.tr/";
    private static GeckoRuntime runtime;
    private GeckoSession session;
    private boolean canGoBack = false;

    private boolean isOwnHost(String uri) {
        Uri u = Uri.parse(uri);
        String sc = u.getScheme();
        String h = u.getHost();
        return ("http".equals(sc) || "https".equals(sc)) && h != null
                && (h.equals("fenetkin.com.tr") || h.endsWith(".fenetkin.com.tr"));
    }

    private void openExternal(String uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri)));
        } catch (Exception e) {
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        GeckoView view = new GeckoView(this);
        setContentView(view);

        if (runtime == null) {
            runtime = GeckoRuntime.create(getApplicationContext());
        }

        session = new GeckoSession();

        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onCanGoBack(GeckoSession s, boolean can) {
                canGoBack = can;
            }

            @Override
            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest r) {
                String sc = Uri.parse(r.uri).getScheme();
                if (isOwnHost(r.uri) || "about".equals(sc) || "data".equals(sc) || "blob".equals(sc)) {
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                }
                openExternal(r.uri);
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }

            @Override
            public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                if (isOwnHost(uri)) {
                    session.loadUri(uri);
                } else {
                    openExternal(uri);
                }
                return null;
            }

            @Override
            public GeckoResult<String> onLoadError(GeckoSession s, String uri, WebRequestError e) {
                String page = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px'>"
                        + "<h2>Baglanti kurulamadi</h2>"
                        + "<p>Internet baglantini kontrol et.</p>"
                        + "<button style='font-size:18px;padding:12px 24px' onclick=\"location.href='" + HOME + "'\">Tekrar dene</button>"
                        + "</body></html>";
                return GeckoResult.fromValue("data:text/html;charset=utf-8," + Uri.encode(page));
            }
        });

        session.setPromptDelegate(new GeckoSession.PromptDelegate() {
            @Override
            public GeckoResult<PromptResponse> onAlertPrompt(GeckoSession s, final AlertPrompt prompt) {
                final GeckoResult<PromptResponse> res = new GeckoResult<>();
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(prompt.message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                res.complete(prompt.dismiss());
                            }
                        }).show();
                return res;
            }

            @Override
            public GeckoResult<PromptResponse> onButtonPrompt(GeckoSession s, final ButtonPrompt prompt) {
                final GeckoResult<PromptResponse> res = new GeckoResult<>();
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(prompt.message)
                        .setCancelable(false)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                res.complete(prompt.confirm(ButtonPrompt.Type.POSITIVE));
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                res.complete(prompt.confirm(ButtonPrompt.Type.NEGATIVE));
                            }
                        }).show();
                return res;
            }
        });

        session.open(runtime);
        view.setSession(session);
        session.loadUri(HOME);
    }

    @Override
    public void onBackPressed() {
        if (canGoBack && session != null) {
            session.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
