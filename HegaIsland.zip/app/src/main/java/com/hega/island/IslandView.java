package com.hega.island;

import android.animation.ValueAnimator;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class IslandView extends FrameLayout {
    static final int IDLE = 0, COMPACT = 1, CHARGE = 2, NOTIF = 3, MUSIC = 4;

    private SharedPreferences sp;
    private float d;
    private final Handler h = new Handler(Looper.getMainLooper());
    private FrameLayout pill;
    private final GradientDrawable bg = new GradientDrawable();
    private LinearLayout compactL, chargeL, notifL, musicL;
    private ImageView cArt, mArt, nIcon;
    private Eq cEq, mEq;
    private Ring ring;
    private TextView chLabel, chPct, nTitle, nText, mTitle, mArtist;
    private Glyph gPrev, gPlay, gNext;
    private Bar bar;
    private int mode = IDLE, baseMode = IDLE, curW, curH;
    private ValueAnimator anim;
    private MediaController mc;
    private PendingIntent notifIntent;
    private String lastTitle = "";

    private final Runnable back = new Runnable() {
        @Override public void run() { go(baseMode); }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateBar();
            if (mode == MUSIC) h.postDelayed(this, 500);
        }
    };

    private final MediaController.Callback cb = new MediaController.Callback() {
        @Override public void onMetadataChanged(MediaMetadata m) { refreshMedia(); }
        @Override public void onPlaybackStateChanged(PlaybackState s) { refreshMedia(); }
        @Override public void onSessionDestroyed() { setMedia(null); }
    };

    public IslandView(Context c) {
        super(c);
        sp = c.getSharedPreferences("island", Context.MODE_PRIVATE);
        d = c.getResources().getDisplayMetrics().density;

        pill = new FrameLayout(c);
        bg.setColor(Color.BLACK);
        pill.setBackground(bg);
        pill.setClipToOutline(true);

        compactL = row(c);
        compactL.setPadding(p(10), 0, p(12), 0);
        cArt = img(c, 20, 10);
        cEq = new Eq(c);
        cEq.setLayoutParams(new LinearLayout.LayoutParams(p(18), p(14)));
        View sp1 = new View(c);
        sp1.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        compactL.addView(cArt);
        compactL.addView(sp1);
        compactL.addView(cEq);

        chargeL = row(c);
        chargeL.setPadding(p(12), 0, p(16), 0);
        ring = new Ring(c);
        ring.setLayoutParams(new LinearLayout.LayoutParams(p(32), p(32)));
        chLabel = tv(c, 13, Color.WHITE, false);
        LinearLayout.LayoutParams lw = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        lw.leftMargin = p(10);
        chLabel.setLayoutParams(lw);
        chPct = tv(c, 17, 0xFF30D158, true);
        chargeL.addView(ring);
        chargeL.addView(chLabel);
        chargeL.addView(chPct);

        notifL = row(c);
        notifL.setPadding(p(14), p(10), p(14), p(10));
        nIcon = img(c, 40, 10);
        LinearLayout nc = new LinearLayout(c);
        nc.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        nl.leftMargin = p(12);
        nc.setLayoutParams(nl);
        nTitle = tv(c, 14, Color.WHITE, true);
        nText = tv(c, 12, 0xFFB0B0B5, false);
        nc.addView(nTitle);
        nc.addView(nText);
        notifL.addView(nIcon);
        notifL.addView(nc);

        musicL = new LinearLayout(c);
        musicL.setOrientation(LinearLayout.VERTICAL);
        musicL.setGravity(Gravity.CENTER_VERTICAL);
        musicL.setPadding(p(16), p(10), p(16), p(10));
        musicL.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        LinearLayout r1 = new LinearLayout(c);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        mArt = img(c, 52, 10);
        LinearLayout mc1 = new LinearLayout(c);
        mc1.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        ml.leftMargin = p(12);
        mc1.setLayoutParams(ml);
        mTitle = tv(c, 15, Color.WHITE, true);
        mArtist = tv(c, 13, 0xFFB0B0B5, false);
        mc1.addView(mTitle);
        mc1.addView(mArtist);
        mEq = new Eq(c);
        mEq.setLayoutParams(new LinearLayout.LayoutParams(p(22), p(18)));
        r1.addView(mArt);
        r1.addView(mc1);
        r1.addView(mEq);
        bar = new Bar(c);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, p(4));
        bl.topMargin = p(10);
        bar.setLayoutParams(bl);
        LinearLayout r2 = new LinearLayout(c);
        r2.setGravity(Gravity.CENTER);
        gPrev = new Glyph(c, Glyph.PREV);
        gPlay = new Glyph(c, Glyph.PLAY);
        gNext = new Glyph(c, Glyph.NEXT);
        gPrev.setLayoutParams(new LinearLayout.LayoutParams(p(60), p(40)));
        gPlay.setLayoutParams(new LinearLayout.LayoutParams(p(60), p(40)));
        gNext.setLayoutParams(new LinearLayout.LayoutParams(p(60), p(40)));
        r2.addView(gPrev);
        r2.addView(gPlay);
        r2.addView(gNext);
        musicL.addView(r1);
        musicL.addView(bar);
        musicL.addView(r2);

        View[] all = {compactL, chargeL, notifL, musicL};
        for (View v : all) {
            v.setVisibility(GONE);
            pill.addView(v, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }

        int[] t = target(IDLE);
        curW = t[0];
        curH = t[1];
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(curW, curH, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(pill, plp);
        apply(curW, curH);

        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onTap(); }
        });
        pill.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { openApp(); return true; }
        });
        gPrev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { ctl(0); }
        });
        gPlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { ctl(1); }
        });
        gNext.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { ctl(2); }
        });
    }

    private int p(int dp) { return (int) (dp * d); }

    private LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        return l;
    }

    private TextView tv(Context c, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private ImageView img(Context c, int size, int radius) {
        ImageView v = new ImageView(c);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackgroundColor(0xFF2C2C2E);
        final float r = radius * d;
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View x, Outline o) {
                o.setRoundRect(0, 0, x.getWidth(), x.getHeight(), r);
            }
        });
        v.setClipToOutline(true);
        v.setLayoutParams(new LinearLayout.LayoutParams(p(size), p(size)));
        return v;
    }

    private void openApp() {
        Intent i = new Intent(getContext(), MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
    }

    private int[] target(int m) {
        float s = sp.getInt("scale", 100) / 100f;
        int iw = p(sp.getInt("w", 110));
        int ih = p(sp.getInt("h", 32));
        int max = getResources().getDisplayMetrics().widthPixels - p(16);
        int w, hh;
        switch (m) {
            case COMPACT: w = (int) (iw * 1.5f); hh = ih; break;
            case CHARGE: w = (int) (p(250) * s); hh = Math.max(ih, (int) (p(54) * s)); break;
            case NOTIF: w = (int) (p(320) * s); hh = Math.max(ih, (int) (p(68) * s)); break;
            case MUSIC: w = (int) (p(340) * s); hh = Math.max(ih, (int) (p(150) * s)); break;
            default: w = iw; hh = ih;
        }
        return new int[]{Math.min(w, max), hh};
    }

    private void apply(float w, float hh) {
        curW = (int) w;
        curH = (int) hh;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) pill.getLayoutParams();
        lp.width = curW;
        lp.height = curH;
        pill.setLayoutParams(lp);
        bg.setCornerRadius(Math.min(curH / 2f, p(28)));
        pill.invalidateOutline();
    }

    private void morph(final int w, final int hh, int dur) {
        if (anim != null) anim.cancel();
        final int fw = curW, fh = curH;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(dur);
        anim.setInterpolator(w > fw ? new OvershootInterpolator(1.0f) : new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float f = (Float) a.getAnimatedValue();
                apply(fw + (w - fw) * f, fh + (hh - fh) * f);
            }
        });
        anim.start();
    }

    private void show(int m) {
        View t = m == COMPACT ? compactL : m == CHARGE ? chargeL : m == NOTIF ? notifL : m == MUSIC ? musicL : null;
        View[] all = {compactL, chargeL, notifL, musicL};
        for (View v : all) {
            v.animate().cancel();
            if (v == t) {
                v.setVisibility(VISIBLE);
                v.setAlpha(0f);
                v.animate().alpha(1f).setStartDelay(120).setDuration(200).start();
            } else {
                v.setVisibility(GONE);
            }
        }
    }

    private void go(int m) {
        mode = m;
        int[] t = target(m);
        morph(t[0], t[1], (m == IDLE || m == COMPACT) ? 280 : 420);
        show(m);
        h.removeCallbacks(tick);
        if (m == MUSIC) {
            updateBar();
            h.postDelayed(tick, 500);
        }
    }

    private void flash(int m, long ms) {
        h.removeCallbacks(back);
        go(m);
        h.postDelayed(back, ms);
    }

    public void relayout() {
        if (anim != null) anim.cancel();
        int[] t = target(mode);
        apply(t[0], t[1]);
    }

    public void refresh() {
        relayout();
        refreshMedia();
    }

    private void onTap() {
        if (mode == NOTIF) {
            if (notifIntent != null) {
                try { notifIntent.send(); } catch (PendingIntent.CanceledException ignored) { }
            }
            h.removeCallbacks(back);
            go(baseMode);
        } else if (mode == MUSIC || mode == CHARGE) {
            h.removeCallbacks(back);
            go(baseMode);
        } else if (mc != null && sp.getBoolean("music", true)) {
            flash(MUSIC, 6000);
        }
    }

    private void ctl(int k) {
        if (mc == null) return;
        MediaController.TransportControls t = mc.getTransportControls();
        if (k == 0) {
            t.skipToPrevious();
        } else if (k == 2) {
            t.skipToNext();
        } else {
            PlaybackState s = mc.getPlaybackState();
            if (s != null && s.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
        }
        if (mode == MUSIC) {
            h.removeCallbacks(back);
            h.postDelayed(back, 6000);
        }
    }

    public void showBattery(int level, String label) {
        ring.set(level / 100f);
        chPct.setText(level + "%");
        chPct.setTextColor(level <= 20 ? 0xFFFF453A : 0xFF30D158);
        chLabel.setText(label);
        flash(CHARGE, 3800);
    }

    public void showNotif(Drawable ic, CharSequence t, CharSequence x, PendingIntent pi) {
        nIcon.setImageDrawable(ic);
        nTitle.setText(t == null ? "" : t);
        nText.setText(x == null ? "" : x);
        nText.setVisibility(x == null ? GONE : VISIBLE);
        notifIntent = pi;
        flash(NOTIF, 4500);
    }

    public void setMedia(MediaController c) {
        if (c != null && mc != null && c.getSessionToken().equals(mc.getSessionToken())) return;
        if (c == null && mc == null) return;
        if (mc != null) {
            try { mc.unregisterCallback(cb); } catch (Exception ignored) { }
        }
        mc = c;
        lastTitle = "";
        if (c != null) c.registerCallback(cb);
        refreshMedia();
    }

    private void refreshMedia() {
        boolean on = sp.getBoolean("music", true);
        if (mc == null || !on) {
            baseMode = IDLE;
            cEq.run(false);
            mEq.run(false);
            if (mode == COMPACT || (mode == MUSIC && mc == null)) go(IDLE);
            return;
        }
        MediaMetadata md = mc.getMetadata();
        PlaybackState ps = mc.getPlaybackState();
        String t = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        String a = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        if (a == null && md != null) a = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
        Bitmap b = null;
        if (md != null) {
            b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        }
        boolean playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
        mTitle.setText(t == null ? "" : t);
        mArtist.setText(a == null ? "" : a);
        cArt.setImageBitmap(b);
        mArt.setImageBitmap(b);
        gPlay.setType(playing ? Glyph.PAUSE : Glyph.PLAY);
        cEq.run(playing);
        mEq.run(playing);
        baseMode = playing ? COMPACT : IDLE;
        String key = t == null ? "" : t;
        if (playing && !key.isEmpty() && !key.equals(lastTitle)) {
            lastTitle = key;
            flash(MUSIC, 4500);
        } else if ((mode == IDLE || mode == COMPACT) && mode != baseMode) {
            go(baseMode);
        }
    }

    private void updateBar() {
        if (mc == null) return;
        PlaybackState ps = mc.getPlaybackState();
        MediaMetadata md = mc.getMetadata();
        if (ps == null || md == null) {
            bar.set(0f);
            return;
        }
        long dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long pos = ps.getPosition();
        if (ps.getState() == PlaybackState.STATE_PLAYING) {
            long dt = SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime();
            pos += (long) (dt * ps.getPlaybackSpeed());
        }
        bar.set(dur > 0 ? Math.min(1f, Math.max(0f, pos / (float) dur)) : 0f);
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h.removeCallbacksAndMessages(null);
        if (mc != null) {
            try { mc.unregisterCallback(cb); } catch (Exception ignored) { }
        }
        if (anim != null) anim.cancel();
    }

    static class Glyph extends View {
        static final int PREV = 0, PLAY = 1, PAUSE = 2, NEXT = 3;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int type;

        Glyph(Context c, int t) {
            super(c);
            type = t;
            p.setColor(Color.WHITE);
        }

        void setType(int t) {
            if (t != type) {
                type = t;
                invalidate();
            }
        }

        @Override protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float u = Math.min(getWidth(), getHeight()) * 0.3f;
            Path q = new Path();
            if (type == PLAY) {
                q.moveTo(cx - u * 0.7f, cy - u);
                q.lineTo(cx + u, cy);
                q.lineTo(cx - u * 0.7f, cy + u);
                q.close();
                c.drawPath(q, p);
            } else if (type == PAUSE) {
                c.drawRoundRect(cx - u * 0.85f, cy - u, cx - u * 0.2f, cy + u, u * 0.2f, u * 0.2f, p);
                c.drawRoundRect(cx + u * 0.2f, cy - u, cx + u * 0.85f, cy + u, u * 0.2f, u * 0.2f, p);
            } else if (type == NEXT) {
                q.moveTo(cx - u, cy - u * 0.8f);
                q.lineTo(cx, cy);
                q.lineTo(cx - u, cy + u * 0.8f);
                q.close();
                q.moveTo(cx, cy - u * 0.8f);
                q.lineTo(cx + u, cy);
                q.lineTo(cx, cy + u * 0.8f);
                q.close();
                c.drawPath(q, p);
                c.drawRect(cx + u, cy - u * 0.8f, cx + u * 1.25f, cy + u * 0.8f, p);
            } else {
                q.moveTo(cx + u, cy - u * 0.8f);
                q.lineTo(cx, cy);
                q.lineTo(cx + u, cy + u * 0.8f);
                q.close();
                q.moveTo(cx, cy - u * 0.8f);
                q.lineTo(cx - u, cy);
                q.lineTo(cx, cy + u * 0.8f);
                q.close();
                c.drawPath(q, p);
                c.drawRect(cx - u * 1.25f, cy - u * 0.8f, cx - u, cy + u * 0.8f, p);
            }
        }
    }

    static class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float f;

        Bar(Context c) { super(c); }

        void set(float v) {
            if (v != f) {
                f = v;
                invalidate();
            }
        }

        @Override protected void onDraw(Canvas c) {
            float r = getHeight() / 2f;
            p.setColor(0x33FFFFFF);
            c.drawRoundRect(0, 0, getWidth(), getHeight(), r, r, p);
            p.setColor(Color.WHITE);
            c.drawRoundRect(0, 0, getWidth() * f, getHeight(), r, r, p);
        }
    }

    static class Eq extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean on;

        Eq(Context c) {
            super(c);
            p.setColor(0xFFFF9F0A);
        }

        void run(boolean v) {
            on = v;
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), hh = getHeight(), bw = w / 7f;
            long t = SystemClock.uptimeMillis();
            for (int i = 0; i < 4; i++) {
                float f = on ? 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(t / 170.0 + i * 1.9)) : 0.2f;
                float bh = hh * f;
                float x = i * 2 * bw;
                c.drawRoundRect(x, (hh - bh) / 2f, x + bw, (hh + bh) / 2f, bw / 2f, bw / 2f, p);
            }
            if (on) postInvalidateOnAnimation();
        }
    }

    static class Ring extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float lvl, prog = 1f;

        Ring(Context c) { super(c); }

        void set(float l) {
            lvl = l;
            ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
            a.setDuration(1000);
            a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator x) {
                    prog = (Float) x.getAnimatedValue();
                    invalidate();
                }
            });
            a.start();
        }

        @Override protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            float sw = s * 0.13f;
            RectF r = new RectF(sw, sw, s - sw, s - sw);
            int col = lvl <= 0.2f ? 0xFFFF453A : 0xFF30D158;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sw);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x33FFFFFF);
            c.drawOval(r, p);
            p.setColor(col);
            c.drawArc(r, -90f, 360f * lvl * prog, false, p);
            Path b = new Path();
            b.moveTo(s * 0.56f, s * 0.26f);
            b.lineTo(s * 0.36f, s * 0.56f);
            b.lineTo(s * 0.50f, s * 0.56f);
            b.lineTo(s * 0.44f, s * 0.76f);
            b.lineTo(s * 0.66f, s * 0.44f);
            b.lineTo(s * 0.52f, s * 0.44f);
            b.close();
            p.setStyle(Paint.Style.FILL);
            c.drawPath(b, p);
        }
    }
}
