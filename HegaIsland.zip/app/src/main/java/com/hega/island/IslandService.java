package com.hega.island;

import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.view.Gravity;
import android.view.WindowManager;

import java.util.List;

public class IslandService extends NotificationListenerService {
    static IslandView view;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private SharedPreferences sp;
    private MediaSessionManager msm;
    private boolean added, up, full;
    private String last = "";
    private float d;

    private final SharedPreferences.OnSharedPreferenceChangeListener pl =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override public void onSharedPreferenceChanged(SharedPreferences s, String k) { sync(); }
            };

    private final MediaSessionManager.OnActiveSessionsChangedListener sl =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override public void onActiveSessionsChanged(List<MediaController> l) { pick(l); }
            };

    private final BroadcastReceiver br = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (view == null || !sp.getBoolean("charge", true)) return;
            String a = i.getAction();
            if (Intent.ACTION_POWER_CONNECTED.equals(a)) {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                view.showBattery(pct(b), "Şarj oluyor");
            } else if (Intent.ACTION_BATTERY_LOW.equals(a)) {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                view.showBattery(pct(b), "Pil zayıf");
            } else if (Intent.ACTION_BATTERY_CHANGED.equals(a)) {
                int l = pct(i);
                boolean plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
                if (plug && l >= 100 && !full) {
                    full = true;
                    view.showBattery(100, "Şarj tamamlandı");
                }
                if (l < 100) full = false;
            }
        }
    };

    static void testCharge() {
        if (view != null) view.showBattery(78, "Şarj oluyor");
    }

    private static int pct(Intent b) {
        if (b == null) return 0;
        int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
        int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return s > 0 ? l * 100 / s : l;
    }

    @Override public void onListenerConnected() {
        if (up) return;
        up = true;
        sp = getSharedPreferences("island", MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        sp.registerOnSharedPreferenceChangeListener(pl);
        Intent s = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        full = pct(s) >= 100;
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_BATTERY_LOW);
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(br, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(br, f);
        }
        attach();
    }

    @Override public void onListenerDisconnected() {
        down();
    }

    @Override public void onDestroy() {
        down();
        super.onDestroy();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (view != null) view.relayout();
    }

    private void down() {
        if (!up) return;
        up = false;
        try { sp.unregisterOnSharedPreferenceChangeListener(pl); } catch (Exception ignored) { }
        try { unregisterReceiver(br); } catch (Exception ignored) { }
        detach();
    }

    private void sync() {
        if (!up) return;
        if (!sp.getBoolean("on", true)) {
            detach();
            return;
        }
        if (!added) {
            attach();
            return;
        }
        lp.y = (int) (sp.getInt("y", 10) * d);
        try { wm.updateViewLayout(view, lp); } catch (Exception ignored) { }
        view.refresh();
    }

    private void attach() {
        if (added || wm == null || !sp.getBoolean("on", true) || !Settings.canDrawOverlays(this)) return;
        IslandView v = new IslandView(this);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        p.y = (int) (sp.getInt("y", 10) * d);
        try {
            wm.addView(v, p);
        } catch (Exception e) {
            return;
        }
        view = v;
        lp = p;
        added = true;
        hook();
    }

    private void detach() {
        if (msm != null) {
            try { msm.removeOnActiveSessionsChangedListener(sl); } catch (Exception ignored) { }
        }
        if (added && view != null) {
            try { wm.removeView(view); } catch (Exception ignored) { }
        }
        view = null;
        added = false;
    }

    private void hook() {
        try {
            msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            ComponentName cn = new ComponentName(this, IslandService.class);
            msm.addOnActiveSessionsChangedListener(sl, cn);
            pick(msm.getActiveSessions(cn));
        } catch (Exception ignored) { }
    }

    private void pick(List<MediaController> l) {
        if (view == null) return;
        MediaController best = null;
        if (l != null) {
            for (MediaController c : l) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    best = c;
                    break;
                }
                if (best == null) best = c;
            }
        }
        view.setMedia(best);
    }

    @Override public void onNotificationPosted(StatusBarNotification s) {
        if (!up || view == null || !sp.getBoolean("notif", true)) return;
        if (s.getPackageName().equals(getPackageName())) return;
        Notification n = s.getNotification();
        if ((n.flags & (Notification.FLAG_GROUP_SUMMARY | Notification.FLAG_ONGOING_EVENT)) != 0) return;
        String cat = n.category;
        if (Notification.CATEGORY_TRANSPORT.equals(cat)
                || Notification.CATEGORY_PROGRESS.equals(cat)
                || Notification.CATEGORY_SERVICE.equals(cat)) return;
        Bundle e = n.extras;
        CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence x = e.getCharSequence(Notification.EXTRA_TEXT);
        if (t == null && x == null) return;
        String key = s.getKey() + "|" + t + "|" + x;
        if (key.equals(last)) return;
        last = key;
        Drawable ic = null;
        try {
            Icon li = n.getLargeIcon();
            if (li != null) ic = li.loadDrawable(this);
            if (ic == null) ic = getPackageManager().getApplicationIcon(s.getPackageName());
        } catch (Exception ignored) { }
        view.showNotif(ic, t, x, n.contentIntent);
    }
}
