package com.hega.island;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private TextView status;
    private float d;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("island", MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;

        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(40), dp(20), dp(32));
        sv.addView(l);

        TextView title = new TextView(this);
        title.setText("Hega Island");
        title.setTextSize(26);
        l.addView(title);

        status = new TextView(this);
        status.setPadding(0, dp(12), 0, dp(12));
        l.addView(status);

        button(l, "1. Üstte gösterme iznini ver", new Runnable() {
            @Override public void run() {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        button(l, "2. Uygulama bilgisi (kısıtlı ayarlara izin ver)", new Runnable() {
            @Override public void run() {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        button(l, "3. Bildirim erişimini ver", new Runnable() {
            @Override public void run() {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        button(l, "4. Pil optimizasyonu listesi", new Runnable() {
            @Override public void run() {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });

        TextView h1 = new TextView(this);
        h1.setText("Özellikler");
        h1.setTextSize(20);
        h1.setPadding(0, dp(24), 0, dp(4));
        l.addView(h1);
        toggle(l, "Ada açık", "on");
        toggle(l, "Şarj animasyonu", "charge");
        toggle(l, "Bildirimler", "notif");
        toggle(l, "Müzik", "music");

        TextView h2 = new TextView(this);
        h2.setText("Boyut ve konum");
        h2.setTextSize(20);
        h2.setPadding(0, dp(24), 0, dp(4));
        l.addView(h2);
        seek(l, "Boştaki genişlik (dp)", "w", 60, 200, 110);
        seek(l, "Boştaki yükseklik (dp)", "h", 20, 60, 32);
        seek(l, "Üstten boşluk (dp)", "y", 0, 80, 10);
        seek(l, "Genişleyen ada boyutu (%)", "scale", 85, 130, 100);

        TextView h3 = new TextView(this);
        h3.setText("Test");
        h3.setTextSize(20);
        h3.setPadding(0, dp(24), 0, dp(4));
        l.addView(h3);
        button(l, "Şarj animasyonunu dene", new Runnable() {
            @Override public void run() { IslandService.testCharge(); }
        });
        button(l, "Bildirimi dene", new Runnable() {
            @Override public void run() {
                if (IslandService.view == null) return;
                Drawable ic = null;
                try { ic = getPackageManager().getApplicationIcon(getPackageName()); } catch (Exception ignored) { }
                IslandService.view.showNotif(ic, "Hega Island", "Test bildirimi", null);
            }
        });
        button(l, "Varsayılanlara dön", new Runnable() {
            @Override public void run() {
                sp.edit().clear().apply();
                recreate();
            }
        });

        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean o = Settings.canDrawOverlays(this);
        String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        boolean n = en != null && en.contains(getPackageName());
        status.setText("Üstte gösterme izni: " + (o ? "verildi" : "yok")
                + "\nBildirim erişimi: " + (n ? "verildi" : "yok")
                + "\nDurum: " + (IslandService.view != null ? "çalışıyor" : "beklemede"));
        sp.edit().putLong("tick", SystemClock.elapsedRealtime()).apply();
    }

    private int dp(int v) { return (int) (v * d); }

    private void button(LinearLayout l, String t, final Runnable r) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setOnClickListener(new android.view.View.OnClickListener() {
            @Override public void onClick(android.view.View v) { r.run(); }
        });
        l.addView(bt);
    }

    private void toggle(LinearLayout l, String label, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setChecked(sp.getBoolean(key, true));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton bv, boolean c) {
                sp.edit().putBoolean(key, c).apply();
            }
        });
        l.addView(s);
    }

    private void seek(LinearLayout l, final String label, final String key, final int min, int max, int def) {
        final TextView t = new TextView(this);
        int cur = sp.getInt(key, def);
        t.setText(label + ": " + cur);
        t.setPadding(0, dp(14), 0, 0);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                int v = p + min;
                t.setText(label + ": " + v);
                if (u) sp.edit().putInt(key, v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { IslandService.testCharge(); }
        });
        l.addView(t);
        l.addView(s);
    }
}
